function searchNothing() {
    //construct the URL and redirect to it
    window.location = '/people/'
}

