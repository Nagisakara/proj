# CS290-Server-Side-Examples

As the assignment was only to do one webpage, I left the other example webpages as they were, including index. So you need to use /people/ to get to the page that I have prepared for this assignment
